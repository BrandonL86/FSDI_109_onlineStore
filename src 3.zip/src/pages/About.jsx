import "./About.css";

function About() {

    return (

        <div className="about">
            <h1>Brandon Lile</h1>
            <h6>615-555-5555</h6>
        </div>
    );
}

export default About;