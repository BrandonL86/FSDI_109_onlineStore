import "./cart.css";


function Cart(){
    return(
        <div className="cart page">
            <div className="form">
                <h1>Are you ready to purchase?</h1>
                <br />
                    <div className="row">
                        <div className="col">
                        <input type="text" className="form-control" placeholder=" Product Title"></input><br />
                        <input type="file" class="form-control" aria-label="file example" required></input><br />
                        <div class="input-group mb-3">
                        <span class="input-group-text">$</span>
                        <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)"></input>
                        <span class="input-group-text">.00</span>
                        </div>
                            <select class="form-select" required aria-label="select example">
                            <option value="">Category</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                            </select><br />
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
            </div>
                <div className="right-side">
                    <h1>this is the right side</h1>
                </div>
        </div>
    );
}

export default Cart;